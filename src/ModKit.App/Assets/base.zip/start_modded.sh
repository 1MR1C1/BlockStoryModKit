#!/bin/sh
# Block Story — native-Linux BepInEx launcher.
# Steam launch option:  "<this file>" %command%
# Sets up the Unity Doorstop environment and then runs Steam's command UNCHANGED
# (no argument rotation), so it works regardless of Steam's reaper layout and the
# Steam overlay still loads. The game inherits LD_PRELOAD and starts BepInEx.
HERE="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"

export DOORSTOP_ENABLED=1
export DOORSTOP_TARGET_ASSEMBLY="${HERE}/BepInEx/core/BepInEx.Preloader.dll"
export LD_LIBRARY_PATH="${HERE}:${LD_LIBRARY_PATH}"
if [ -z "${LD_PRELOAD}" ]; then
    export LD_PRELOAD="${HERE}/libdoorstop.so"
else
    export LD_PRELOAD="${HERE}/libdoorstop.so:${LD_PRELOAD}"
fi

exec "$@"
