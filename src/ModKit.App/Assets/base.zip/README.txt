==========================================================
  Block Story Mod Kit  —  read me first
==========================================================

A tool for the Steam version of Block Story that installs the modding
framework for you, manages mods, and lets you BUILD your own mods
(by hand, from templates, or with AI). No mods are bundled — you make
or add your own.

EASIEST: the Block Story Mod Kit app
  One download. Open it, go to "Settings" and point it at your Block
  Story folder, then "Setup & Help" -> "Install / update framework".
  After that:
    * Mod Builder tab — pick a starter template (or describe a mod to
      the AI), name it, and "Make my mod". It compiles + installs it.
    * Game API tab — browse the real game classes/items while you work.
    * Launcher tab — turn mods on/off, install .dll/.zip mods you got
      from someone, make profiles, back up, update.
  (Step-by-step guides for everything are inside the app.)

MANUAL: do it yourself
  * Framework (required, once): the mod loader + the "Core" toolbox.
        See INSTALL-Windows.txt / INSTALL-Linux.txt.
  * Mods: each mod is one .dll dropped into BepInEx/plugins/.
        See HOW-TO-ADD-MODS.txt.

BUILDING MODS needs the .NET 8 SDK (the app checks for it and tells you).
PLAYING with mods does NOT need anything extra.

IN GAME:
  * Main-menu "Mods" button — turn each installed mod on/off.
  * Mod hotkeys live in Settings -> Controls (scroll to the bottom),
    grouped by mod, and are rebindable.

NOTE: built for the current Steam build of Block Story; a big game
update could break it until it's rebuilt. Back up saves if cautious.
